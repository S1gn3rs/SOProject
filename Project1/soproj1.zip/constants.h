/// Maximum size of a write command.
#define MAX_WRITE_SIZE 256
/// Maximum size of a string.
#define MAX_STRING_SIZE 40
/// Maximum size of a job file name.
#define MAX_JOB_FILE_NAME_SIZE 256
